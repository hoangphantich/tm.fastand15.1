/** Automatically generated file. DO NOT MODIFY */
package com.asian.hots;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}